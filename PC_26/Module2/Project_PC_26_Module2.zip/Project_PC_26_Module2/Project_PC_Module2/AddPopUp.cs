﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_PC_Module2
{
    public partial class AddPopUp : Form
    {

        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        SqlDataAdapter da = new SqlDataAdapter();
        SqlDataReader dr;
        DataSet ds = new DataSet();
        Config db = new Config();
        public AddPopUp()
        {
            InitializeComponent();
            cn = new SqlConnection(db.Myconnection());


        }


        private void button3_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (Qty.Value ==0)
            {
                ep.Clear();
                ep.SetError(Qty, "Quantity cannot zero");
            }
            else
            {

                Form1 frm = new Form1();
                try
                {
                    cn.Open();
                    cm = new SqlCommand("INSERT INTO detail_order(header_order_id,menu_id, order_price, quantity)VALUES('"+frm.code+"','" + txtID.Text+"','"+txtPrice.Text+"','"+Qty.Value+"')");
                    cn.Close();
                    this.Dispose();
                    frm.loadList();
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

          
        }

        private void txtQty_TextChanged(object sender, EventArgs e)
        {
            int qty = 1;
             txtQty.Text="2";
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
