﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_PC_Module2
{
    public partial class Form1 : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        SqlDataAdapter da = new SqlDataAdapter();
        SqlDataReader dr;
        DataSet ds = new DataSet();
        Config db = new Config();
        public Form1()
        {
            InitializeComponent();
            txtDate.Text = DateTime.Now.ToLongDateString();
            timer1.Start();
            cn = new SqlConnection(db.Myconnection());
            LoadData();
            autoNumber();
        }

        private void autoNumber()
        {
            long hitung;
            string urut;
            try
            {
                cn.Open();
                cm = new SqlCommand("select * from header_order where id in(select max (id) from header_order) order by id desc", cn);
                dr = cm.ExecuteReader();
                dr.Read();
                if (dr.HasRows)
                {
                    hitung = Convert.ToInt16(dr[0].ToString().Substring(dr["id"].ToString().Length - 1))+1;
                    urut = hitung.ToString();
                }
                else
                {
                    urut = "1";
                }
                dr.Close();
                code.Text = urut;
                cn.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime dt = DateTime.Now;
            txtTime.Text = dt.ToString("HH:MM:ss");
        }

        private void btnx2_Click(object sender, EventArgs e)
        {
            txtCustomer.Clear();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                //foods
                cn.Open();
                cm = new SqlCommand("select * from menu where is_favourite=1", cn);
                da = new SqlDataAdapter(cm);
                ds = new DataSet();
                da.Fill(ds, "menu");
                dgvMenu.DataSource = ds;
                dgvMenu.DataMember = "menu";
                dgvMenu.Refresh();
                cn.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void foods()
        {
            try
            {
                //foods
                cn.Open();
                cm = new SqlCommand("select * from menu where menu_category_id=1", cn);
                da = new SqlDataAdapter(cm);
                ds = new DataSet();
                da.Fill(ds, "menu");
                dgvMenu.DataSource = ds;
                dgvMenu.DataMember = "menu";
                dgvMenu.Refresh();
                cn.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void Drink()
        {
            try
            {
                //foods
                cn.Open();
                cm = new SqlCommand("select * from menu where menu_category_id=2", cn);
                da = new SqlDataAdapter(cm);
                ds = new DataSet();
                da.Fill(ds, "menu");
                dgvMenu.DataSource = ds;
                dgvMenu.DataMember = "menu";
                dgvMenu.Refresh();
                cn.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void Snack()
        {
            try
            {
                //foods
                cn.Open();
                cm = new SqlCommand("select * from menu where menu_category_id=3", cn);
                da = new SqlDataAdapter(cm);
                ds = new DataSet();
                da.Fill(ds, "menu");
                dgvMenu.DataSource = ds;
                dgvMenu.DataMember = "menu";
                dgvMenu.Refresh();
                cn.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void othres()
        {
            try
            {
                //foods
                cn.Open();
                cm = new SqlCommand("select * from menu where menu_category_id=4", cn);
                da = new SqlDataAdapter(cm);
                ds = new DataSet();
                da.Fill(ds, "menu");
                dgvMenu.DataSource = ds;
                dgvMenu.DataMember = "menu";
                dgvMenu.Refresh();
                cn.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
        private void Favorite_Click(object sender, EventArgs e)
        {
            sideBar.Height = Favorite.Height;
            sideBar.Left = Favorite.Left;
            LoadData();
        }

        private void Foods_Click(object sender, EventArgs e)
        {
            sideBar.Height = Foods.Height;
            sideBar.Left = Foods.Left;
            foods();
        }

        private void Drinks_Click(object sender, EventArgs e)
        {
            sideBar.Height = Drinks.Height;
            sideBar.Left = Drinks.Left;
            Drink();
        }

        private void Snacks_Click(object sender, EventArgs e)
        {
            sideBar.Height = Snacks.Height;
            sideBar.Left = Snacks.Left;
            Snack();
        }

        private void Others_Click(object sender, EventArgs e)
        {
            sideBar.Height = Others.Height;
            sideBar.Left = Others.Left;
            othres();
        }

        public void loadList()
        {
            try
            {
                //foods
                cn.Open();
                cm = new SqlCommand("select * from vwList where id='"+code.Text+"'", cn);
                da = new SqlDataAdapter(cm);
                ds = new DataSet();
                da.Fill(ds, "vwList");
                dgvList.DataSource = ds;
                dgvList.DataMember = "vwList";
                dgvList.Refresh();
                cn.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }


        }
        private void dgvMenu_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvMenu_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                cn.Open();
                cm = new SqlCommand("INSERT INTO header_order VALUES('" + DateTime.Now.ToLongDateString() + "','" + cmbTable.Text + "','" + txtCustomer.Text + "') ", cn);
                cm.ExecuteNonQuery();
                cn.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            AddPopUp frm = new AddPopUp();
          
            frm.txtID.Text = dgvMenu[0, e.RowIndex].Value.ToString();
            frm.txtFoodName.Text = dgvMenu[2, e.RowIndex].Value.ToString();
            frm.txtPrice.Text = dgvMenu[3, e.RowIndex].Value.ToString();
            frm.txtDescription.Text = dgvMenu[4, e.RowIndex].Value.ToString();
            frm.ShowDialog();

            

        }

        private void dgvList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            loadList();
        }
    }
}
