﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_PC_26_Module3
{
    public partial class Chose_Promo : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        SqlDataAdapter da = new SqlDataAdapter();
        SqlDataReader dr;
        DataSet ds;
        Config db = new Config();
        static string id, name, diskon;

        public  string getID()
        {
            return id;
        }

        public  string getName()
        {
            return name;
        }
        public  string getDiscount()
        {
            return diskon;
        }
       
        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
          

        }

        private void dgv_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = this.dgv.Rows[e.RowIndex];
            id = row.Cells[0].Value.ToString();
            name = row.Cells[1].Value.ToString();
            diskon = row.Cells[2].Value.ToString();
            this.Dispose();
        }

        public Chose_Promo()
        {
            InitializeComponent();

            cn = new SqlConnection(db.Myconncetion());
        }

        private void Chose_Promo_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dB_PC_26_Module3DataSet.promotion' table. You can move, or remove it, as needed.
            this.promotionTableAdapter.Fill(this.dB_PC_26_Module3DataSet.promotion);

            
        }
    }
}
