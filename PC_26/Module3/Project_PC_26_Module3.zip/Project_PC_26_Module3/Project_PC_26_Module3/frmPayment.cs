﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_PC_26_Module3
{
    public partial class frmPayment : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        SqlDataAdapter da = new SqlDataAdapter();
        SqlDataReader dr;
        DataSet ds;
        Config db = new Config();
        public frmPayment()
        {
            InitializeComponent();
            cn = new SqlConnection(db.Myconncetion());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtAmountPaid.Text))
            {
                ep.Clear();
                ep.SetError(txtAmountPaid, "Please enter amount paid");
            }
            else
            {
                Form1 frm = new Form1();
                try
                {
                    cn.Open();
                    cm = new SqlCommand("INSERT INTO payment(header_order_id, promotion_id, payment_type, amount_to_pay, amount_paid)VALUES('"+frm.headeID.Text+"','"+frm.txtIdPromo.Text+"','"+cmbType.Text+ "','" + Convert.ToDouble(txtPayType.Text) + "','" +txtAmountPaid.Text+"')",cn);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Transaction Successfully");
                    this.Dispose();
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void txtAmountPaid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar<46)
            {

            }
            else if (e.KeyChar==8)
            {

            }
            else if ((e.KeyChar<48) ||(e.KeyChar>57))
            {
                e.Handled = true;
            }
        }

        private void txtAmountPaid_TextChanged(object sender, EventArgs e)
        {
            if (txtAmountPaid.Text=="")
            {
                txtAmountPaid.Text = "0";
            }
            double total = Convert.ToDouble(txtPayType.Text);
            double amount = Convert.ToDouble(txtAmountPaid.Text);
            double change = total-amount;
            txtChange.Text = change.ToString();

        }
    }
}
