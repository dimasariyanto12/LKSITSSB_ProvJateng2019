﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_PC_26_Module3
{
    public partial class Form1 : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        SqlDataAdapter da = new SqlDataAdapter();
        SqlDataReader dr;
        DataSet ds;
        Config db = new Config();
        public Form1()
        {
            InitializeComponent();
            timer1.Start();
            Clear();
            txtDate.Text = DateTime.Now.ToLongDateString();
            cn = new SqlConnection(db.Myconncetion());

        }

        private void Clear()
        {
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dB_PC_26_Module3DataSet2.vw_list' table. You can move, or remove it, as needed.
         
            // TODO: This line of code loads data into the 'dB_PC_26_Module3DataSet1.detail_order' table. You can 
            // TODO: This line of code loads data into the 'headerioerdeModule3DataSet.header_order' table. You can move, or remove it, as needed.
            this.header_orderTableAdapter.Fill(this.headerioerdeModule3DataSet.header_order);

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime dt = DateTime.Now;
            txtTime.Text = dt.ToString("HH:MM:ss");
        }


        private void cusAscend()
        {
            try
            {
                cn.Open();
                cm = new SqlCommand("select * from header_order order by customer_name ASC", cn);
                da = new SqlDataAdapter(cm);
                ds = new DataSet();
                da.Fill(ds, "header_order");
                dgv.DataSource = ds;
                dgv.DataMember = "header_order";
                dgv.Refresh();
                cn.Close();

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void cusDescend()
        {
            try
            {
                cn.Open();
                cm = new SqlCommand("select * from header_order order by customer_name DESC", cn);
                da = new SqlDataAdapter(cm);
                ds = new DataSet();
                da.Fill(ds, "header_order");
                dgv.DataSource = ds;
                dgv.DataMember = "header_order";
                dgv.Refresh();
                cn.Close();

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void TblAscend()
        {
            try
            {
                cn.Open();
                cm = new SqlCommand("select * from header_order order by table_number ASC", cn);
                da = new SqlDataAdapter(cm);
                ds = new DataSet();
                da.Fill(ds, "header_order");
                dgv.DataSource = ds;
                dgv.DataMember = "header_order";
                dgv.Refresh();
                cn.Close();

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
        private void Tbldescend()
        {
            try
            {
                cn.Open();
                cm = new SqlCommand("select * from header_order order by table_number DESC", cn);
                da = new SqlDataAdapter(cm);
                ds = new DataSet();
                da.Fill(ds, "header_order");
                dgv.DataSource = ds;
                dgv.DataMember = "header_order";
                dgv.Refresh();
                cn.Close();

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            if (cmbSort.Text== "Customer(ascending)")
            {
                cusAscend();
            }
            else if (cmbSort.Text == "Customer(descending)")
            {
                cusDescend();
            }
            else if (cmbSort.Text == "Table(ascending)")
            {
                TblAscend();
            }
            else if (cmbSort.Text == "Table(descending)")
            {
                Tbldescend();
            }
        }

        private void cmbSort_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Chose_Promo frm = new Chose_Promo();
            frm.ShowDialog();
            txtPromo.Text = frm.getName();
            txtIdPromo.Text = frm.getID();
            txtDisCount.Text = "("+frm.getDiscount()+"%)";
          
        }

        private void label7_Click(object sender, EventArgs e)
        {
            txtPromo.Clear();
        }

        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            table.Text=dgv[2, e.RowIndex].Value.ToString();
            headeID.Text = dgv[0, e.RowIndex].Value.ToString();
            nmCus.Text = dgv[1, e.RowIndex].Value.ToString();
            try
            {
                cn.Open();
                cm = new SqlCommand("select * from vw_list where id='" + dgv[0, e.RowIndex].Value + "'",cn);
                da = new SqlDataAdapter(cm);
                ds = new DataSet();
                da.Fill(ds, "vw_list");
                dgvList.DataSource = ds;
                dgvList.DataMember = "vw_list";
                dgvList.Refresh();
                cn.Close();
                txtSubtotal.Text = dgvList[4, e.RowIndex].Value.ToString();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }


        private void hitung()
        {

           
             double subTotal = Convert.ToDouble(txtSubtotal.Text);
            double diskon = Convert.ToDouble(txtDisCount.Text) / 100 * subTotal;
            double Dicount = diskon - subTotal;
            double Tax= Dicount - 10 / 100 *subTotal;
            double serviseChar= 5 / 100 *subTotal;
            double total = subTotal - Dicount  + serviseChar +Tax ;

            txtSubtotal.Text = subTotal.ToString();
            txtSubDiscount.Text = Dicount.ToString();
            txtTax.Text = tax.ToString();
            txtServCharge.Text = serviseChar.ToString();
            txtTotal.Text = total.ToString();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (dgvList.Rows.Count<=0)
            {
                MessageBox.Show("Please Select Customer or table Order","INFORMATION",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
            else
            {
                frmPayment frm = new frmPayment();
                frm.txtDate.Text = DateTime.Now.ToLongDateString() + DateTime.Now.ToShortTimeString();
                frm.txtNAme.Text = nmCus.Text;
                frm.txtTable.Text = table.Text;
                
                frm.txtPayType.Text = txtSubtotal.Text;
                
                

               frm.ShowDialog();
            }
        }

        private void dgvList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Payhistory frm = new Payhistory();
            frm.Show();
        }
    }
}
