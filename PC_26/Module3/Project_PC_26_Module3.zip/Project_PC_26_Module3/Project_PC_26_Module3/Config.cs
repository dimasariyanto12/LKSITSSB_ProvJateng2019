﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_PC_26_Module3
{
    class Config
    {

        public  string Myconncetion()
        {
            string con = @"Data Source=.\SQLEXPRESS;Initial Catalog=DB_PC_26_Module3;Integrated Security=True";
            return con;
        }
    }
}
