﻿namespace Project_PC_26_Module3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtDate = new System.Windows.Forms.Label();
            this.txtTime = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbSort = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPromo = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dgvList = new System.Windows.Forms.DataGridView();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.headerioerdeModule3DataSet = new Project_PC_26_Module3.HeaderioerdeModule3DataSet();
            this.headerorderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.header_orderTableAdapter = new Project_PC_26_Module3.HeaderioerdeModule3DataSetTableAdapters.header_orderTableAdapter();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ordermadetimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tablenumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.button2 = new System.Windows.Forms.Button();
            this.txtIdPromo = new System.Windows.Forms.Label();
            this.txtDisCount = new System.Windows.Forms.Label();
            this.dB_PC_26_Module3DataSet1 = new Project_PC_26_Module3.DB_PC_26_Module3DataSet1();
            this.detailorderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.detail_orderTableAdapter = new Project_PC_26_Module3.DB_PC_26_Module3DataSet1TableAdapters.detail_orderTableAdapter();
            this.dB_PC_26_Module3DataSet2 = new Project_PC_26_Module3.DB_PC_26_Module3DataSet2();
            this.vwlistBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vw_listTableAdapter = new Project_PC_26_Module3.DB_PC_26_Module3DataSet2TableAdapters.vw_listTableAdapter();
            this.idDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderpriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtTotal = new System.Windows.Forms.Label();
            this.txtTax = new System.Windows.Forms.Label();
            this.txtSubDiscount = new System.Windows.Forms.Label();
            this.txtServCharge = new System.Windows.Forms.Label();
            this.txtSubtotal = new System.Windows.Forms.Label();
            this.tax = new System.Windows.Forms.Label();
            this.nmCus = new System.Windows.Forms.Label();
            this.servise = new System.Windows.Forms.Label();
            this.table = new System.Windows.Forms.Label();
            this.headeID = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvList)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.headerioerdeModule3DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.headerorderBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_PC_26_Module3DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.detailorderBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_PC_26_Module3DataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vwlistBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // txtDate
            // 
            this.txtDate.AutoSize = true;
            this.txtDate.Location = new System.Drawing.Point(13, 13);
            this.txtDate.Name = "txtDate";
            this.txtDate.Size = new System.Drawing.Size(41, 20);
            this.txtDate.TabIndex = 0;
            this.txtDate.Text = "Date";
            // 
            // txtTime
            // 
            this.txtTime.AutoSize = true;
            this.txtTime.Location = new System.Drawing.Point(13, 33);
            this.txtTime.Name = "txtTime";
            this.txtTime.Size = new System.Drawing.Size(42, 20);
            this.txtTime.TabIndex = 1;
            this.txtTime.Text = "Time";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(464, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Sort";
            // 
            // cmbSort
            // 
            this.cmbSort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSort.FormattingEnabled = true;
            this.cmbSort.Items.AddRange(new object[] {
            "Customer(ascending)",
            "Customer(descending)",
            "Table(ascending)",
            "Table(descending)"});
            this.cmbSort.Location = new System.Drawing.Point(516, 14);
            this.cmbSort.Name = "cmbSort";
            this.cmbSort.Size = new System.Drawing.Size(231, 28);
            this.cmbSort.TabIndex = 3;
            this.cmbSort.SelectedIndexChanged += new System.EventHandler(this.cmbSort_SelectedIndexChanged);
            this.cmbSort.TextChanged += new System.EventHandler(this.comboBox1_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(357, 51);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(146, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Use Promotion Code";
            // 
            // txtPromo
            // 
            this.txtPromo.Location = new System.Drawing.Point(516, 49);
            this.txtPromo.Name = "txtPromo";
            this.txtPromo.Size = new System.Drawing.Size(126, 27);
            this.txtPromo.TabIndex = 5;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dgv);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(27, 97);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(319, 350);
            this.panel1.TabIndex = 6;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.OrangeRed;
            this.panel2.Controls.Add(this.label5);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(319, 46);
            this.panel2.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(121, 14);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 20);
            this.label5.TabIndex = 7;
            this.label5.Text = "Data Order";
            // 
            // dgv
            // 
            this.dgv.AllowUserToAddRows = false;
            this.dgv.AllowUserToDeleteRows = false;
            this.dgv.AutoGenerateColumns = false;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.ordermadetimeDataGridViewTextBoxColumn,
            this.tablenumberDataGridViewTextBoxColumn,
            this.customernameDataGridViewTextBoxColumn});
            this.dgv.DataSource = this.headerorderBindingSource;
            this.dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv.Location = new System.Drawing.Point(0, 46);
            this.dgv.Name = "dgv";
            this.dgv.ReadOnly = true;
            this.dgv.Size = new System.Drawing.Size(319, 304);
            this.dgv.TabIndex = 1;
            this.dgv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellClick);
            this.dgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellContentClick);
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.servise);
            this.panel3.Controls.Add(this.tax);
            this.panel3.Controls.Add(this.txtTotal);
            this.panel3.Controls.Add(this.txtTax);
            this.panel3.Controls.Add(this.txtSubDiscount);
            this.panel3.Controls.Add(this.txtServCharge);
            this.panel3.Controls.Add(this.txtSubtotal);
            this.panel3.Controls.Add(this.txtDisCount);
            this.panel3.Controls.Add(this.label16);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.dgvList);
            this.panel3.Location = new System.Drawing.Point(389, 97);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(359, 350);
            this.panel3.TabIndex = 7;
            // 
            // dgvList
            // 
            this.dgvList.AllowUserToAddRows = false;
            this.dgvList.AllowUserToDeleteRows = false;
            this.dgvList.AutoGenerateColumns = false;
            this.dgvList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn1,
            this.menuidDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.quantityDataGridViewTextBoxColumn,
            this.orderpriceDataGridViewTextBoxColumn});
            this.dgvList.DataSource = this.vwlistBindingSource;
            this.dgvList.Location = new System.Drawing.Point(-1, 45);
            this.dgvList.Name = "dgvList";
            this.dgvList.ReadOnly = true;
            this.dgvList.Size = new System.Drawing.Size(358, 187);
            this.dgvList.TabIndex = 0;
            this.dgvList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvList_CellContentClick);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.OrangeRed;
            this.panel4.Controls.Add(this.label6);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(357, 46);
            this.panel4.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(121, 14);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 20);
            this.label6.TabIndex = 7;
            this.label6.Text = "List Order";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(648, 51);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(99, 25);
            this.button1.TabIndex = 8;
            this.button1.Text = "chose";
            this.button1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(620, 52);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(16, 20);
            this.label7.TabIndex = 9;
            this.label7.Text = "x";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 236);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 20);
            this.label8.TabIndex = 10;
            this.label8.Text = "SUBTOTAL";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 306);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(125, 20);
            this.label9.TabIndex = 11;
            this.label9.Text = "SERVICE CHARGE";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(13, 259);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(81, 20);
            this.label10.TabIndex = 11;
            this.label10.Text = "DISCOUNT";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(13, 282);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 20);
            this.label11.TabIndex = 12;
            this.label11.Text = "TAX";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(13, 329);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(54, 20);
            this.label16.TabIndex = 17;
            this.label16.Text = "TOTAL";
            // 
            // headerioerdeModule3DataSet
            // 
            this.headerioerdeModule3DataSet.DataSetName = "HeaderioerdeModule3DataSet";
            this.headerioerdeModule3DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // headerorderBindingSource
            // 
            this.headerorderBindingSource.DataMember = "header_order";
            this.headerorderBindingSource.DataSource = this.headerioerdeModule3DataSet;
            // 
            // header_orderTableAdapter
            // 
            this.header_orderTableAdapter.ClearBeforeFill = true;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn.HeaderText = "id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Visible = false;
            // 
            // ordermadetimeDataGridViewTextBoxColumn
            // 
            this.ordermadetimeDataGridViewTextBoxColumn.DataPropertyName = "order_made_time";
            this.ordermadetimeDataGridViewTextBoxColumn.HeaderText = "order_made_time";
            this.ordermadetimeDataGridViewTextBoxColumn.Name = "ordermadetimeDataGridViewTextBoxColumn";
            this.ordermadetimeDataGridViewTextBoxColumn.ReadOnly = true;
            this.ordermadetimeDataGridViewTextBoxColumn.Visible = false;
            // 
            // tablenumberDataGridViewTextBoxColumn
            // 
            this.tablenumberDataGridViewTextBoxColumn.DataPropertyName = "table_number";
            this.tablenumberDataGridViewTextBoxColumn.HeaderText = "Table Number";
            this.tablenumberDataGridViewTextBoxColumn.Name = "tablenumberDataGridViewTextBoxColumn";
            this.tablenumberDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // customernameDataGridViewTextBoxColumn
            // 
            this.customernameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.customernameDataGridViewTextBoxColumn.DataPropertyName = "customer_name";
            this.customernameDataGridViewTextBoxColumn.HeaderText = "Customer";
            this.customernameDataGridViewTextBoxColumn.Name = "customernameDataGridViewTextBoxColumn";
            this.customernameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Green;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(544, 453);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(203, 29);
            this.button2.TabIndex = 10;
            this.button2.Text = "PAYMENT";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtIdPromo
            // 
            this.txtIdPromo.AutoSize = true;
            this.txtIdPromo.Location = new System.Drawing.Point(400, 14);
            this.txtIdPromo.Name = "txtIdPromo";
            this.txtIdPromo.Size = new System.Drawing.Size(57, 20);
            this.txtIdPromo.TabIndex = 11;
            this.txtIdPromo.Text = "idCode";
            this.txtIdPromo.Visible = false;
            // 
            // txtDisCount
            // 
            this.txtDisCount.AutoSize = true;
            this.txtDisCount.Location = new System.Drawing.Point(95, 259);
            this.txtDisCount.Name = "txtDisCount";
            this.txtDisCount.Size = new System.Drawing.Size(81, 20);
            this.txtDisCount.TabIndex = 19;
            this.txtDisCount.Text = "DISCOUNT";
            // 
            // dB_PC_26_Module3DataSet1
            // 
            this.dB_PC_26_Module3DataSet1.DataSetName = "DB_PC_26_Module3DataSet1";
            this.dB_PC_26_Module3DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // detailorderBindingSource
            // 
            this.detailorderBindingSource.DataMember = "detail_order";
            this.detailorderBindingSource.DataSource = this.dB_PC_26_Module3DataSet1;
            // 
            // detail_orderTableAdapter
            // 
            this.detail_orderTableAdapter.ClearBeforeFill = true;
            // 
            // dB_PC_26_Module3DataSet2
            // 
            this.dB_PC_26_Module3DataSet2.DataSetName = "DB_PC_26_Module3DataSet2";
            this.dB_PC_26_Module3DataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // vwlistBindingSource
            // 
            this.vwlistBindingSource.DataMember = "vw_list";
            this.vwlistBindingSource.DataSource = this.dB_PC_26_Module3DataSet2;
            // 
            // vw_listTableAdapter
            // 
            this.vw_listTableAdapter.ClearBeforeFill = true;
            // 
            // idDataGridViewTextBoxColumn1
            // 
            this.idDataGridViewTextBoxColumn1.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn1.HeaderText = "id";
            this.idDataGridViewTextBoxColumn1.Name = "idDataGridViewTextBoxColumn1";
            this.idDataGridViewTextBoxColumn1.ReadOnly = true;
            this.idDataGridViewTextBoxColumn1.Visible = false;
            // 
            // menuidDataGridViewTextBoxColumn
            // 
            this.menuidDataGridViewTextBoxColumn.DataPropertyName = "menu_id";
            this.menuidDataGridViewTextBoxColumn.HeaderText = "menu_id";
            this.menuidDataGridViewTextBoxColumn.Name = "menuidDataGridViewTextBoxColumn";
            this.menuidDataGridViewTextBoxColumn.ReadOnly = true;
            this.menuidDataGridViewTextBoxColumn.Visible = false;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "Qty";
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            this.quantityDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // orderpriceDataGridViewTextBoxColumn
            // 
            this.orderpriceDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.orderpriceDataGridViewTextBoxColumn.DataPropertyName = "order_price";
            this.orderpriceDataGridViewTextBoxColumn.HeaderText = "Price";
            this.orderpriceDataGridViewTextBoxColumn.Name = "orderpriceDataGridViewTextBoxColumn";
            this.orderpriceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // txtTotal
            // 
            this.txtTotal.AutoSize = true;
            this.txtTotal.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotal.Location = new System.Drawing.Point(300, 326);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(54, 20);
            this.txtTotal.TabIndex = 28;
            this.txtTotal.Text = "TOTAL";
            this.txtTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtTax
            // 
            this.txtTax.AutoSize = true;
            this.txtTax.Location = new System.Drawing.Point(319, 282);
            this.txtTax.Name = "txtTax";
            this.txtTax.Size = new System.Drawing.Size(35, 20);
            this.txtTax.TabIndex = 27;
            this.txtTax.Text = "TAX";
            this.txtTax.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtSubDiscount
            // 
            this.txtSubDiscount.AutoSize = true;
            this.txtSubDiscount.Location = new System.Drawing.Point(273, 259);
            this.txtSubDiscount.Name = "txtSubDiscount";
            this.txtSubDiscount.Size = new System.Drawing.Size(81, 20);
            this.txtSubDiscount.TabIndex = 25;
            this.txtSubDiscount.Text = "DISCOUNT";
            this.txtSubDiscount.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtServCharge
            // 
            this.txtServCharge.AutoSize = true;
            this.txtServCharge.Location = new System.Drawing.Point(229, 306);
            this.txtServCharge.Name = "txtServCharge";
            this.txtServCharge.Size = new System.Drawing.Size(125, 20);
            this.txtServCharge.TabIndex = 26;
            this.txtServCharge.Text = "SERVICE CHARGE";
            this.txtServCharge.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtSubtotal
            // 
            this.txtSubtotal.AutoSize = true;
            this.txtSubtotal.Location = new System.Drawing.Point(278, 235);
            this.txtSubtotal.Name = "txtSubtotal";
            this.txtSubtotal.Size = new System.Drawing.Size(76, 20);
            this.txtSubtotal.TabIndex = 24;
            this.txtSubtotal.Text = "SUBTOTAL";
            this.txtSubtotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tax
            // 
            this.tax.AutoSize = true;
            this.tax.Location = new System.Drawing.Point(95, 282);
            this.tax.Name = "tax";
            this.tax.Size = new System.Drawing.Size(37, 20);
            this.tax.TabIndex = 29;
            this.tax.Text = "10%";
            // 
            // nmCus
            // 
            this.nmCus.AutoSize = true;
            this.nmCus.Location = new System.Drawing.Point(403, 462);
            this.nmCus.Name = "nmCus";
            this.nmCus.Size = new System.Drawing.Size(42, 20);
            this.nmCus.TabIndex = 12;
            this.nmCus.Text = "Time";
            this.nmCus.Visible = false;
            // 
            // servise
            // 
            this.servise.AutoSize = true;
            this.servise.Location = new System.Drawing.Point(144, 306);
            this.servise.Name = "servise";
            this.servise.Size = new System.Drawing.Size(29, 20);
            this.servise.TabIndex = 30;
            this.servise.Text = "5%";
            // 
            // table
            // 
            this.table.AutoSize = true;
            this.table.Location = new System.Drawing.Point(403, 482);
            this.table.Name = "table";
            this.table.Size = new System.Drawing.Size(42, 20);
            this.table.TabIndex = 13;
            this.table.Text = "Time";
            this.table.Visible = false;
            // 
            // headeID
            // 
            this.headeID.AutoSize = true;
            this.headeID.Location = new System.Drawing.Point(355, 462);
            this.headeID.Name = "headeID";
            this.headeID.Size = new System.Drawing.Size(42, 20);
            this.headeID.TabIndex = 14;
            this.headeID.Text = "Time";
            this.headeID.Visible = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(30, 462);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(203, 29);
            this.button3.TabIndex = 15;
            this.button3.Text = "PAYMENT HISTORY";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(759, 501);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.headeID);
            this.Controls.Add(this.table);
            this.Controls.Add(this.nmCus);
            this.Controls.Add(this.txtIdPromo);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtPromo);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmbSort);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtTime);
            this.Controls.Add(this.txtDate);
            this.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Esemka Restaurant";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvList)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.headerioerdeModule3DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.headerorderBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_PC_26_Module3DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.detailorderBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_PC_26_Module3DataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vwlistBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txtDate;
        private System.Windows.Forms.Label txtTime;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbSort;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPromo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label7;
        private HeaderioerdeModule3DataSet headerioerdeModule3DataSet;
        private System.Windows.Forms.BindingSource headerorderBindingSource;
        private HeaderioerdeModule3DataSetTableAdapters.header_orderTableAdapter header_orderTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ordermadetimeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tablenumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label txtDisCount;
        private DB_PC_26_Module3DataSet1 dB_PC_26_Module3DataSet1;
        private System.Windows.Forms.BindingSource detailorderBindingSource;
        private DB_PC_26_Module3DataSet1TableAdapters.detail_orderTableAdapter detail_orderTableAdapter;
        private DB_PC_26_Module3DataSet2 dB_PC_26_Module3DataSet2;
        private System.Windows.Forms.BindingSource vwlistBindingSource;
        private DB_PC_26_Module3DataSet2TableAdapters.vw_listTableAdapter vw_listTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn menuidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderpriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label txtTotal;
        private System.Windows.Forms.Label txtTax;
        private System.Windows.Forms.Label txtSubDiscount;
        private System.Windows.Forms.Label txtServCharge;
        private System.Windows.Forms.Label txtSubtotal;
        private System.Windows.Forms.Label tax;
        private System.Windows.Forms.Label servise;
        public System.Windows.Forms.Label txtIdPromo;
        public System.Windows.Forms.Label nmCus;
        public System.Windows.Forms.Label table;
        public System.Windows.Forms.DataGridView dgvList;
        public System.Windows.Forms.DataGridView dgv;
        public System.Windows.Forms.Label headeID;
        public System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.Button button2;
        public System.Windows.Forms.Button button3;
    }
}

