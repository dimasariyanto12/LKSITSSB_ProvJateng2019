﻿namespace Project_PC_26_Module3
{
    partial class Chose_Promo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.dB_PC_26_Module3DataSet = new Project_PC_26_Module3.DB_PC_26_Module3DataSet();
            this.promotionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.promotionTableAdapter = new Project_PC_26_Module3.DB_PC_26_Module3DataSetTableAdapters.promotionTableAdapter();
            this.IDPromo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NameCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiskonPromo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.minimumspentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.starttimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.endtimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_PC_26_Module3DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.promotionBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv
            // 
            this.dgv.AllowUserToAddRows = false;
            this.dgv.AllowUserToDeleteRows = false;
            this.dgv.AutoGenerateColumns = false;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDPromo,
            this.NameCode,
            this.DiskonPromo,
            this.minimumspentDataGridViewTextBoxColumn,
            this.starttimeDataGridViewTextBoxColumn,
            this.endtimeDataGridViewTextBoxColumn});
            this.dgv.DataSource = this.promotionBindingSource;
            this.dgv.Location = new System.Drawing.Point(3, 40);
            this.dgv.Name = "dgv";
            this.dgv.ReadOnly = true;
            this.dgv.Size = new System.Drawing.Size(303, 304);
            this.dgv.TabIndex = 0;
            this.dgv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellClick);
            this.dgv.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellDoubleClick);
            // 
            // dB_PC_26_Module3DataSet
            // 
            this.dB_PC_26_Module3DataSet.DataSetName = "DB_PC_26_Module3DataSet";
            this.dB_PC_26_Module3DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // promotionBindingSource
            // 
            this.promotionBindingSource.DataMember = "promotion";
            this.promotionBindingSource.DataSource = this.dB_PC_26_Module3DataSet;
            // 
            // promotionTableAdapter
            // 
            this.promotionTableAdapter.ClearBeforeFill = true;
            // 
            // IDPromo
            // 
            this.IDPromo.DataPropertyName = "id";
            this.IDPromo.HeaderText = "id";
            this.IDPromo.Name = "IDPromo";
            this.IDPromo.ReadOnly = true;
            this.IDPromo.Visible = false;
            // 
            // NameCode
            // 
            this.NameCode.DataPropertyName = "code";
            this.NameCode.HeaderText = "code";
            this.NameCode.Name = "NameCode";
            this.NameCode.ReadOnly = true;
            // 
            // DiskonPromo
            // 
            this.DiskonPromo.DataPropertyName = "discount";
            this.DiskonPromo.HeaderText = "discount";
            this.DiskonPromo.Name = "DiskonPromo";
            this.DiskonPromo.ReadOnly = true;
            // 
            // minimumspentDataGridViewTextBoxColumn
            // 
            this.minimumspentDataGridViewTextBoxColumn.DataPropertyName = "minimum_spent";
            this.minimumspentDataGridViewTextBoxColumn.HeaderText = "minimum_spent";
            this.minimumspentDataGridViewTextBoxColumn.Name = "minimumspentDataGridViewTextBoxColumn";
            this.minimumspentDataGridViewTextBoxColumn.ReadOnly = true;
            this.minimumspentDataGridViewTextBoxColumn.Visible = false;
            // 
            // starttimeDataGridViewTextBoxColumn
            // 
            this.starttimeDataGridViewTextBoxColumn.DataPropertyName = "start_time";
            this.starttimeDataGridViewTextBoxColumn.HeaderText = "start_time";
            this.starttimeDataGridViewTextBoxColumn.Name = "starttimeDataGridViewTextBoxColumn";
            this.starttimeDataGridViewTextBoxColumn.ReadOnly = true;
            this.starttimeDataGridViewTextBoxColumn.Visible = false;
            // 
            // endtimeDataGridViewTextBoxColumn
            // 
            this.endtimeDataGridViewTextBoxColumn.DataPropertyName = "end_time";
            this.endtimeDataGridViewTextBoxColumn.HeaderText = "end_time";
            this.endtimeDataGridViewTextBoxColumn.Name = "endtimeDataGridViewTextBoxColumn";
            this.endtimeDataGridViewTextBoxColumn.ReadOnly = true;
            this.endtimeDataGridViewTextBoxColumn.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 347);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(181, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "*Double click to chose promo";
            // 
            // Chose_Promo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(307, 373);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgv);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Chose_Promo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chose Promo";
            this.Load += new System.EventHandler(this.Chose_Promo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_PC_26_Module3DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.promotionBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv;
        private DB_PC_26_Module3DataSet dB_PC_26_Module3DataSet;
        private System.Windows.Forms.BindingSource promotionBindingSource;
        private DB_PC_26_Module3DataSetTableAdapters.promotionTableAdapter promotionTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDPromo;
        private System.Windows.Forms.DataGridViewTextBoxColumn NameCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiskonPromo;
        private System.Windows.Forms.DataGridViewTextBoxColumn minimumspentDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn starttimeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn endtimeDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label1;
    }
}