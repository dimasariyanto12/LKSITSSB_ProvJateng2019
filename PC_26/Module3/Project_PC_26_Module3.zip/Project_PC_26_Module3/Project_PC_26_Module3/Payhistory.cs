﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_PC_26_Module3
{
    public partial class Payhistory : Form
    {

        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        SqlDataAdapter da = new SqlDataAdapter();
        SqlDataReader dr;
        DataSet ds;
        Config db = new Config();
        public Payhistory()
        {
            InitializeComponent();
            cn = new SqlConnection(db.Myconncetion());
        }

        private void Payhistory_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dB_PC_26_Module3DataSet3.vwHistory' table. You can move, or remove it, as needed.
         

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                cn.Open();
                cm = new SqlCommand("select * from vw_list where order_made_time between '" + dateTimePicker1.Text + "' and '" + dateTimePicker2 + "''", cn);
                da = new SqlDataAdapter(cm);
                ds = new DataSet();
                da.Fill(ds, "vw_list");
                dgvList.DataSource = ds;
                dgvList.DataMember = "vw_list";
                dgvList.Refresh();
                cn.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
    }
}
